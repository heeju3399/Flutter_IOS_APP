
class MyWord {
  static const String EXAMPLE = '';
  static const String USERID = 'userid';
  static const String LOGIN = 'LogIn';
  static const String DATA = 'data';
  static const String TEST_SITE = 'TestSite';
  static const String GET_TEXT_FILED_MAP = 'getTextFiledMap';
  static const String EMPTY = 'Empty';
  static const String SEARCH = 'Search';
  static const String PASS = 'pass';
  static const String NO = 'no';
  static const String USER_ID_PATH = '/repo/userid.txt';
  static const String ipAndPort = 'http://172.30.1.10:3000/';












}