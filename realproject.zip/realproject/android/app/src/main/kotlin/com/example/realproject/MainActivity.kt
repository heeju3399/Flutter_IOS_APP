package com.example.realproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
